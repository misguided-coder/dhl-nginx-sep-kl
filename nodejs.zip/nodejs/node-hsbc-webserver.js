var express = require('express');

var server  = express();

server.use(function (req, res, next) {
  res.set('Cache-control', 'public, max-age=300');
  next();
})


server.use(express.static(__dirname+"/pages"));
server.use(express.static(__dirname+"/css"));
server.use(express.static(__dirname+"/pages/css"));

server.get("/hsbc/home",(req,res)=>{
	console.log('Request received for HSBC Home Page!!')
	res.writeHead(200,{'Content-Type':'text/html'});
	res.write("<h1>HSBC Home Page</h1>");
	res.write("<h1>Welcome to HSBC</h1>");
	res.end();
});

server.get("/hsbc/accounts",(req,res)=>{
	console.log('Request received for HSBC Accounts Page!!')
	res.writeHead(200,{'Content-Type':'text/html'});
	res.write("<h1>HSBC Accounts Page</h1>");
	res.write("<h1>Welcome to HSBC Easy Banking</h1>");
	res.end();
});

server.get("/hsbc/customer",(req,res)=>{
	console.log('Request received for HSBC Customers Page!!')
	res.writeHead(200,{'Content-Type':'text/html'});
	res.write("<h1>HSBC Customers Page</h1>");
	res.write("<h1>Welcome Mr as our valuable customer</h1>");
	res.end();
});


server.get("/hsbc/*",(req,res)=>{
	console.log('Handling Error and Returing  HSBC Error Page!!')
	res.writeHead(404,{'Content-Type':'text/html'});
	res.write("<h1>HSBC Error Page</h1>");
	res.write("<h1>Page under construction!!!!</h1>");
	res.end();
});

var PORT = process.argv.slice(2)[0];

server.listen(PORT,()=>{
	console.log(`Node server is listening on ${PORT}!!!`);
});




