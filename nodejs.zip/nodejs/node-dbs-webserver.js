var express = require('express');

var server  = express();

server.use(function (req, res, next) {
  res.set('Cache-control', 'public, max-age=300');
  next();
})


server.use(express.static(__dirname+"/pages"));
server.use(express.static(__dirname+"/css"));
server.use(express.static(__dirname+"/pages/css"));

server.get("/dbs/home",(req,res)=>{
	console.log('Request received for DBS Home Page!!')
	res.writeHead(200,{'Content-Type':'text/html'});
	res.write("<h1>DBS  Home Page</h1>");
	res.write("<h1>Welcome to DBS </h1>");
	res.end();
});

server.get("/dbs/car",(req,res)=>{
	console.log('Request received for DBS Car Page!!')
	res.sendFile(__dirname+"/pages/car.html");
});

server.get("/dbs/weather",(req,res)=>{
	console.log('Request received for DBS Weather Page!!')
	res.sendFile(__dirname+"/pages/weather.html");
});

server.get("/dbs/news",(req,res)=>{
	console.log('Request received for DBS News Page!!')
	res.sendFile(__dirname+"/pages/news.html");
});

server.get("/dbs/*",(req,res)=>{
	console.log('Handling Error and Returing DBS Error Page!!')
	res.statusCode = 404;
	res.sendFile(__dirname+"/pages/404.html");
});

var PORT = process.argv.slice(2)[0];

server.listen(PORT,()=>{
	console.log(`Node server is listening on ${PORT}!!!`);
});




